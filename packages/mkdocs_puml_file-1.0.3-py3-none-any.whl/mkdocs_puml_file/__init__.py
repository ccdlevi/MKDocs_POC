from .plugin import PlantUmlFilePlugin

__all__ = [PlantUmlFilePlugin]