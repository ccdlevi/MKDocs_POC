from .plugin import ConfluencePublisherPlugin
