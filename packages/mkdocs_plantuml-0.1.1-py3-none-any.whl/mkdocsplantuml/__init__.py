from .colocator import PlantUMLColocator
from .plugin import PlantumlCoLocatedPlugin